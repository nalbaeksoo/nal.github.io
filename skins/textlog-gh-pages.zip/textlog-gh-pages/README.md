# TextLog

> Textlog is a minimalist, lefty-style Jekyll theme designed for documentation based blog.

[![LICENSE](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE) ![GENERATOR](https://img.shields.io/badge/made_with-jekyll-blue.svg) ![VERSION](https://img.shields.io/badge/current_version-1.5-green.svg) ![TRAVIS-CI](https://travis-ci.org/heiswayi/textlog.svg?branch=gh-pages)

- **Demo:** https://heiswayi.github.io/textlog/

![SCREENSHOT](https://i.imgur.com/yXqbM4S.png)

## License

[MIT](LICENSE.md)
