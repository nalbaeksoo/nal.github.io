---
layout: page
title: "关于：About"
---
Welcome to visit my blog!

#### 1.Personal Info
Name: Xuewen Pan(潘学文)  
Gender: Male  
City: Wuhan, China  
Career: Software developer(Android&Linux&Web)  

#### 2.My Links
Blog: <http://www.panxw.com>  
GitHub: <https://github.com/panxw>  
LinkedIn: <http://www.linkedin.com/in/panxw>  


#### 3.Contract
Email: winfirm#163.com  
QQ: 85902258  

### 4.Domain For Sale
danbaili.com  
fangxinyu.com  
maicaiwa.com  
babytoycar.com  
youth168.com  
