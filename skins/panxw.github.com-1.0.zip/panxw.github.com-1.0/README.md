Jekyll博客模板
================

#### 1.浏览
http://www.panxw.com, 支持PC与智能机访问。  

#### 2.模板使用
修改_config.yml与_includes目录下相关文件进行配置。  
模板可任意使用，但请保留本站**友情链接**。  

#### 3.联系作者
Email: winfirm(#)163.com  
QQ交流群: 168563980  

#### 4.赞助
想给作者予以鼓励？欢迎打赏吧。  
支付宝:  
<img width="200" height="200" src="http://o83o7w0hk.bkt.clouddn.com//donate_qr/donate_alipay.jpg"/>

微信:  
<img width="200" height="200" src="http://o83o7w0hk.bkt.clouddn.com//donate_qr/donate_weixin.jpg"/>

